@echo off
title ULTRON -- Text Mode
color 0A

echo ==============================================
echo   ULTRON -- TEXT-ONLY MODE
echo ==============================================
echo.
echo Wake-word microphone service has been disabled.
echo Type "Hey Ultron" in the ULTRON chat to activate.
echo.
call "%~dp0START_ULTRON.bat"
