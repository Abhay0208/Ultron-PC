# ULTRON PC — Text-Only Mode

ULTRON now starts in an **INACTIVE** text state. There is no microphone input and no spoken output.

## Activation
Type:

`Hey Ultron`

ULTRON changes to **ACTIVE** and accepts commands.

## Commands
- `Hey Ultron` — activate
- `Sleep` / `Deactivate Ultron` — enter standby
- Normal requests — send to the configured text LLM and execute available tools

## LLM
The default backend is Ollama:

```text
ollama pull llama3.2
ollama serve
```

You can change `llm_provider`, `llm_url`, and `llm_model` in `config/api_keys.json`.

## Start
Run `START_ULTRON.bat`, or:

```text
python main.py
```

The old wake-word listener file remains only for compatibility; it is no longer launched by the normal text-mode launcher.
